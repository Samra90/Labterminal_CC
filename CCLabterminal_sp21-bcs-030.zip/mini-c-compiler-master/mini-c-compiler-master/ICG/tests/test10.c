#include <stdio.h>
int main()
{
	int 9abi = 10;
}
