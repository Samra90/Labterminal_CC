#include <stdio.h>

void main()
{
	int a,b,c,d;

	//a = d * b + c;
	//a = (b-c)*d + (b-c)*d;
	//a = b+c*d;
	//a = b*(-c) + b*(-c);
	if (a<3)
	{
		if(c<d)
		{
		a = 98;
		}
		else
		{
		a = d * b + c;
		}
	}
	else
	{
		a++;
	}
}
