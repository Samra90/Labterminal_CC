#include<stdio.h>

void main()
{
    int i=3,n=6;
    float a=0.0;
    a = i+n;
}
