#include<stdio.h>

struct student
{
  int rollNum;
  int marks;
}student1;

int main()
{
 int a = 1, b=0;

 student1.rollNum = 1;
 student1.marks = 90;

 if(a >= 1 && a <= 10)
   	b++;

 else
       {  b--;
        /* }
}
