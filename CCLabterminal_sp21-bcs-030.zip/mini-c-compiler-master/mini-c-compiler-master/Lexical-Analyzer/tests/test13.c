// Mixture of tests, comments

#include<stdio.h>
int main()
{
	int a, b;
	char c;
	for(a = 0; a < 29; a++)
	{
		if(a < 15) {
			printf("Hello World");
		}
	}
	int x = a + b;
	// Single Line Comment
	/* This is a 
	   multi-line comment */ 
	   
	int var1;
	char var2;
	printf("%d",x);
}
