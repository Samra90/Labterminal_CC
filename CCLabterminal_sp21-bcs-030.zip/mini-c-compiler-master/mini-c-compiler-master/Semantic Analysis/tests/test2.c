#include<stdio.h>



void main(){
	int a,b,c,d,e,f,g,h;

	c=a+b;
	d=a*b;
	e=a/b;
	f=a%b;
	g=a&&b;
	h=a||b;
	h=a*(a+b);
	h=a*a+b*b;
	

}
